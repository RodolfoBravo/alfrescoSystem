# Alfresco Content Services (ACS) Docker Compose

Please refer to the [documentation](/docs/docker-compose/README.md) for information on the Docker compose file and deployment instructions.
