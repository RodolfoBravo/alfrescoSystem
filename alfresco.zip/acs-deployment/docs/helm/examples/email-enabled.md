# Documentation moved

Please now refer to the [alfresco-repository chart
documentation](https://github.com/Alfresco/alfresco-helm-charts/blob/main/charts/alfresco-repository/docs/email.md)
